     <!-- nav -->
 <nav  class="navbar navbar-expand-lg navbar-light px-5" style="background-color: #3B3131;">
    
    <a class="navbar-brand ml-5" href="./dashboard.php">
        <img src="/img/logo-1.png" width="90" height="80" alt="Apex Dental Solution Clinic">
    </a>
    <ul class="navbar-nav mr-auto mt-2 mt-lg-0"></ul>
    
    <div class="user-cart">  
    </div>  
</nav>
